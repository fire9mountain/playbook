#!/bin/bash

nohup /data/node/node_exporter >node-exporter.log 2>&1  &
